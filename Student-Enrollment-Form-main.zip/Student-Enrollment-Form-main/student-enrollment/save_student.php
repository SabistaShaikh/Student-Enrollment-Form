<?php
$connection = mysqli_connect('localhost', 'root', '', 'student');

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_POST['rollNo'], $_POST['fullName'], $_POST['class'], $_POST['birthDate'], $_POST['address'], $_POST['enrollmentDate'])) {
    $rollNo = mysqli_real_escape_string($connection, $_POST['rollNo']);
    $fullName = mysqli_real_escape_string($connection, $_POST['fullName']);
    $class = mysqli_real_escape_string($connection, $_POST['class']);
    $birthDate = mysqli_real_escape_string($connection, $_POST['birthDate']);
    $address = mysqli_real_escape_string($connection, $_POST['address']);
    $enrollmentDate = mysqli_real_escape_string($connection, $_POST['enrollmentDate']);


    if (empty($rollNo) || empty($fullName) || empty($class) || empty($birthDate) || empty($address) || empty($enrollmentDate)) {
        die("Error: All fields are required.");
    }


    $query = "SELECT * FROM enrollment_form WHERE rollNo = '$rollNo'";
    $result = mysqli_query($connection, $query);

    if (mysqli_num_rows($result) > 0) {
        die("Error: Roll number already exists.");
    }


    $insertQuery = "INSERT INTO enrollment_form(rollNo, fullName, class, birthDate, address, enrollmentDate) 
                    VALUES ('$rollNo', '$fullName', '$class', '$birthDate', '$address', '$enrollmentDate')";

    if (mysqli_query($connection, $insertQuery)) {
        echo "Data saved successfully.";
    } else {
        echo "Error: " . mysqli_error($connection);
    }
} else {
    echo "Error: Invalid request.";
}

mysqli_close($connection);
?>